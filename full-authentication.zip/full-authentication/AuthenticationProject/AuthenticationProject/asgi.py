import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from Core.routing import websocket_urlpatterns  # Import your WebSocket URL patterns

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AuthenticationProject.settings')

# ProtocolTypeRouter will route requests based on protocol (HTTP or WebSocket)
application = ProtocolTypeRouter({
    "http": get_asgi_application(),  # For HTTP requests
    "websocket": AuthMiddlewareStack(  # For WebSocket connections
        URLRouter(
            websocket_urlpatterns  # Routes defined in Core.routing
        )
    ),
})
