from django.shortcuts import render, redirect,get_object_or_404
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from django.core.mail import EmailMessage
from django.core.paginator import Paginator
from django.utils import timezone
from django.urls import reverse
from .models import *
from django.utils.timezone import localdate
from django.db.models import Count
from .forms import EmpForm
from datetime import datetime
import logging
from django.db.models import Q
import csv
from openpyxl import Workbook
from django.core.exceptions import PermissionDenied
from django.http import JsonResponse
from .models import Todo
from .tasks import send_task_reminder  # Assuming you have this function in tasks.py




def home_redirect(request):
    if request.user.is_authenticated:
        return redirect('home')  # Redirect to the home page if authenticated
    return redirect('login')  # Redirect to login if not authenticated

@login_required
def Home(request):
    emp = Emp.objects.all().order_by('id')
    paginator = Paginator(emp, 10000)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'index.html',{'page_obj': page_obj})


def RegisterView(request):

    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        user_data_has_error = False

        if User.objects.filter(username=username).exists():
            user_data_has_error = True
            messages.error(request, "Username already exists")

        if User.objects.filter(email=email).exists():
            user_data_has_error = True
            messages.error(request, "Email already exists")

        if len(password) < 5:
            user_data_has_error = True
            messages.error(request, "Password must be at least 5 characters")

        if user_data_has_error:
            return redirect('register')
        else:
            new_user = User.objects.create_user(
                first_name=first_name,
                last_name=last_name,
                email=email, 
                username=username,
                password=password
            )
            messages.success(request, "Account created. Login now")
            return redirect('login')

    return render(request, 'register.html')

def LoginView(request):

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)

            return redirect('home')
        
        else:
            messages.error(request, "Invalid login credentials")
            return redirect('login')

    return render(request, 'login.html')

def LogoutView(request):

    logout(request)

    return redirect('login')

def ForgotPassword(request):

    if request.method == "POST":
        email = request.POST.get('email')

        try:
            user = User.objects.get(email=email)

            new_password_reset = PasswordReset(user=user)
            new_password_reset.save()

            password_reset_url = reverse('reset-password', kwargs={'reset_id': new_password_reset.reset_id})

            full_password_reset_url = f'{request.scheme}://{request.get_host()}{password_reset_url}'

            email_body = f'Reset your password using the link below:\n\n\n{full_password_reset_url}'
        
            email_message = EmailMessage(
                'Reset your password', # email subject
                email_body,
                settings.EMAIL_HOST_USER, # email sender
                [email] # email  receiver 
            )

            email_message.fail_silently = True
            email_message.send()

            return redirect('password-reset-sent', reset_id=new_password_reset.reset_id)

        except User.DoesNotExist:
            messages.error(request, f"No user with email '{email}' found")
            return redirect('forgot-password')

    return render(request, 'forgot_password.html')

def PasswordResetSent(request, reset_id):

    if PasswordReset.objects.filter(reset_id=reset_id).exists():
        return render(request, 'password_reset_sent.html')
    else:
        # redirect to forgot password page if code does not exist
        messages.error(request, 'Invalid reset id')
        return redirect('forgot-password')

def ResetPassword(request, reset_id):

    try:
        password_reset_id = PasswordReset.objects.get(reset_id=reset_id)

        if request.method == "POST":
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            passwords_have_error = False

            if password != confirm_password:
                passwords_have_error = True
                messages.error(request, 'Passwords do not match')

            if len(password) < 5:
                passwords_have_error = True
                messages.error(request, 'Password must be at least 5 characters long')

            expiration_time = password_reset_id.created_when + timezone.timedelta(minutes=10)

            if timezone.now() > expiration_time:
                passwords_have_error = True
                messages.error(request, 'Reset link has expired')

                password_reset_id.delete()

            if not passwords_have_error:
                user = password_reset_id.user
                user.set_password(password)
                user.save()

                password_reset_id.delete()

                messages.success(request, 'Password reset. Proceed to login')
                return redirect('login')
            else:
                # redirect back to password reset page and display errors
                return redirect('reset-password', reset_id=reset_id)

    
    except PasswordReset.DoesNotExist:
        
        # redirect to forgot password page if code does not exist
        messages.error(request, 'Invalid reset id')
        return redirect('forgot-password')

    return render(request, 'reset_password.html')

def update_emp(request,id):
    if request.method == 'POST':
        fm = EmpForm(request.POST, instance=Emp.objects.get(pk=id))
        if fm.is_valid():
            fm.save()
            return redirect('home')
    else:    
        emp = Emp.objects.get(pk=id)
        fm = EmpForm(instance=emp)
    return render(request, 'update_emp.html', {'form':fm})


def delete(request, id):
    # Check if the user is a superuser
    if not request.user.is_superuser:
        # If not superuser, deny permission
        raise PermissionDenied("You are not authorized to delete employee records.")

    # If the user is superuser, allow the deletion
    if request.method == 'POST':
        emp = get_object_or_404(Emp, pk=id)
        emp.delete()
        messages.success(request, 'Employee deleted successfully')
        return redirect('home')
    

    
def add_emp(request):
    if request.method == 'POST':
        fm = EmpForm(request.POST, request.FILES)  # Include request.FILES for file uploads
        if fm.is_valid():
            fm.save()
            return redirect('home')  # Redirect to the home page after successful submission
    else:    
        fm = EmpForm()
    
    return render(request, 'add_emp.html', {'form': fm})  # Pass the form to the template




def search_emp(request):
    if request.method == 'POST':
        query = request.POST.get('output', '').strip()
        if query:
            emp = Emp.objects.filter(
                Q(fname__icontains=query) |
                Q(lname__icontains=query) |
                Q(cnic__icontains=query) |
                Q(gender__icontains=query) |
                Q(designation__icontains=query) |
                Q(branch_name__icontains=query) |
                Q(region_name__icontains=query) |
                Q(case_status__icontains=query)
            )
        else:
            emp = Emp.objects.all()  # Handle empty query case by returning all employees, or you could customize this behavior
        return render(request, 'index.html', {'page_obj': emp,})
    
    # If it's a GET request, display all employees or an empty form
    emp = Emp.objects.all()
    return render(request, 'index.html', {'emp': emp})
        



# Export to CSV
@login_required
def export_to_csv(request):
    status_filter = request.GET.get('status')

    # Superuser can view all employees, while non-superusers are restricted by region
    if request.user.is_superuser:
        if status_filter:
            employees = Emp.objects.filter(case_status=status_filter)
        else:
            employees = Emp.objects.all()
    else:
        region_name = request.user.userprofile.region_name  # Assuming user profile has a region_name field
        if status_filter:
            employees = Emp.objects.filter(case_status=status_filter, region_name=region_name)
        else:
            employees = Emp.objects.filter(region_name=region_name)

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="employees.csv"'

    writer = csv.writer(response)
    # Write the headers
    writer.writerow(['Serial No.', 'First Name', 'Last Name', 'CNIC', 'Gender', 'Phone Number', 'Date of Birth', 'Position Applied', 'Branch Name', 'Region Name', 'GM Remarks', 'HR Remarks', 'Case Status','Region Forwarded Case','Group Forwarded Case','Offer Letter Receiving Date'])

    # Write the data
    for emp in employees:
        writer.writerow([emp.id, emp.fname, emp.lname, emp.cnic, emp.gender, emp.phone_number, emp.date_of_birth, emp.designation, emp.branch_name, emp.region_name, emp.GM_remarks, emp.HR_remarks, emp.case_status, emp.region_case_forward_date, emp.group_case_forward_date, emp.offer_letter_receiving_date])

    return response



# Export to Excel
@login_required
def export_to_excel(request):
    status_filter = request.GET.get('status')

    # Superuser can view all employees, while non-superusers are restricted by region
    if request.user.is_superuser:
        if status_filter:
            employees = Emp.objects.filter(case_status=status_filter)
        else:
            employees = Emp.objects.all()
    else:
        region_name = request.user.userprofile.region_name  # Assuming user profile has a region_name field
        if status_filter:
            employees = Emp.objects.filter(case_status=status_filter, region_name=region_name)
        else:
            employees = Emp.objects.filter(region_name=region_name)

    # Create the HttpResponse object with the appropriate Excel header.
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="employees.xlsx"'

    # Create a workbook and add a worksheet
    wb = Workbook()
    ws = wb.active
    ws.title = "Employees"

    # Write the headers
    ws.append(['Serial No.', 'First Name', 'Last Name', 'CNIC', 'Gender', 'Phone Number', 'Date of Birth', 'Position Applied', 'Branch Name', 'Region Name', 'GM Remarks', 'HR Remarks', 'Case Status','Region Forwarded Case','Group Forwarded Case','Offer Letter Receiving Date'])

    # Write the data
    for emp in employees:
        ws.append([emp.id, emp.fname, emp.lname, emp.cnic, emp.gender, emp.phone_number, emp.date_of_birth, emp.designation, emp.branch_name, emp.region_name, emp.GM_remarks, emp.HR_remarks, emp.case_status, emp.region_case_forward_date, emp.group_case_forward_date, emp.offer_letter_receiving_date])

    # Save the Excel file to the response
    wb.save(response)
    return response


@login_required
def dashboard(request):
    if request.user.is_superuser:
        # For superuser, get global counts for all statuses
        in_process_count = Emp.objects.filter(case_status='Hiring Inprocess').count()
        J_process_count = Emp.objects.filter(case_status='Joining Inprocess').count()
        offer_letter_count = Emp.objects.filter(case_status='Offer Letter Issued').count()
        onboard_staff_count = Emp.objects.filter(case_status='Onboard').count()
        offer_letter_rejected = Emp.objects.filter(case_status='Offer Rejected').count()
        resign_staff = Emp.objects.filter(case_status='Resign').count()
    else:
        # For non-superusers, filter by region_name
        try:
            # Check if userprofile and region_name are accessible
            region_name = request.user.userprofile.region_name  # Assuming user profile has region_name field
            
            # Filter based on the region_name
            in_process_count = Emp.objects.filter(case_status='Hiring Inprocess', region_name=region_name).count()
            J_process_count = Emp.objects.filter(case_status='Joining Inprocess', region_name=region_name).count()
            offer_letter_count = Emp.objects.filter(case_status='Offer Letter Issued', region_name=region_name).count()
            onboard_staff_count = Emp.objects.filter(case_status='Onboard', region_name=region_name).count()
            offer_letter_rejected = Emp.objects.filter(case_status='Offer Rejected', region_name=region_name).count()
            resign_staff = Emp.objects.filter(case_status='Resign', region_name=region_name).count()
        except AttributeError as e:
            # Handle case where userprofile or region_name doesn't exist
            return HttpResponse(f"Error: {e}. Please ensure your user profile has a valid region_name field.")

    context = {
        'in_process_count': in_process_count,
        'J_process_count': J_process_count,
        'offer_letter_count': offer_letter_count,
        'onboard_staff_count': onboard_staff_count,
        'offer_letter_rejected': offer_letter_rejected,
        'resign_staff': resign_staff,
    }

    return render(request, 'dashboard.html', context)




def employee_list(request):
    status_filter = request.GET.get('status')
    
    if status_filter:
        employees = Emp.objects.filter(case_status=status_filter)
    else:
        employees = Emp.objects.all()
    
    paginator = Paginator(employees, 10000) 
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status_filter,
    }
    return render(request, 'index.html', context)

def application_user(request):
    if request.user.is_authenticated:  # Remove the parentheses
        return render(request, 'index.html', {'user': request.user.username})  # Fix dictionary syntax
    else:
        return redirect('login')



def employee_detail(request, pk):

    employee = get_object_or_404(Emp, pk=pk)
    
    return render(request, 'index.html', {'employee': employee})




@login_required
def todo_list(request):
    todos = Todo.objects.filter(user=request.user).order_by('-due_date')
    return render(request, 'todo/todo_list.html', {'todos': todos})

@login_required
def create_task(request):
    if request.method == 'POST':
        description = request.POST.get('description')
        task_type = request.POST.get('task_type')
        due_date = request.POST.get('due_date')

        task = Todo.objects.create(
            user=request.user,
            description=description,
            task_type=task_type,
            due_date=due_date,
        )

        send_task_reminder(task.id)  # Send reminder using Celery

        return redirect('todo_list')

    return render(request, 'todo/create_task.html')

@login_required
def edit_task(request, task_id):
    task = Todo.objects.get(id=task_id)
    
    if request.method == 'POST':
        task.description = request.POST.get('description')
        task.task_type = request.POST.get('task_type')
        task.due_date = request.POST.get('due_date')
        task.save()

        return redirect('todo_list')

    return render(request, 'todo/edit_task.html', {'task': task})

@login_required
def delete_task(request, task_id):
    task = Todo.objects.get(id=task_id)
    task.delete()
    return redirect('todo_list')

@login_required
def mark_complete(request, task_id):
    task = Todo.objects.get(id=task_id)
    task.is_completed = True
    task.save()
    return redirect('todo_list')



