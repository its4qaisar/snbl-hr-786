from celery import shared_task
from django.utils import timezone
from .models import Todo
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

@shared_task
def send_task_reminder(task_id):
    try:
        task = Todo.objects.get(pk=task_id)
        if not task.is_completed:
            # Show reminder pop-up logic here
            print(f"Reminder: Your task '{task.description}' is due!")
            # You can also use Django channels to send real-time WebSocket notifications
    except Todo.DoesNotExist:
        print("Task does not exist.")



def send_task_reminder(task_id):
    task = Todo.objects.get(pk=task_id)
    if not task.is_completed:
        # Notify the frontend via WebSocket
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "todo_reminders",  # You can also use user-specific groups
            {
                'type': 'todo_reminder',
                'message': f"Reminder: Your task '{task.description}' is due!"
            }
        )
