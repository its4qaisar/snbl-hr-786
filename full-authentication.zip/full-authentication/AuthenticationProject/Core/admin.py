from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import PasswordReset,Emp,UserProfile,Todo



# Register PasswordReset model in the admin interface
admin.site.register(PasswordReset)


class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'region_name']  # Adjust 'region_name' to match the correct field in your model

# Register the UserProfile model with UserProfileAdmin
admin.site.register(UserProfile, UserProfileAdmin)


@admin.register(Emp)
class EmpAdmin(admin.ModelAdmin):
    def has_delete_permission(self, request, obj=None):
        # Only superusers have delete permissions
        return request.user.is_superuser
    

class ProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'

# Define a new User admin
class UserAdmin(BaseUserAdmin):
    inlines = (ProfileInline,)

    def save_model(self, request, obj, form, change):
        """ Override save_model to ensure no duplicate profiles are created """
        obj.save()
        # Ensure profile creation only happens for users without a profile
        if not hasattr(obj, 'userprofile'):
            UserProfile.objects.create(user=obj)

            

class TodoAdmin(admin.ModelAdmin):
    list_display = ('user', 'description', 'task_type', 'due_date', 'is_completed', 'created_at')
    list_filter = ('task_type', 'is_completed', 'due_date')
    search_fields = ('description', 'user__username')
    ordering = ('due_date',)
    date_hierarchy = 'due_date'

admin.site.register(Todo, TodoAdmin)