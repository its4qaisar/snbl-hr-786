from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import render, redirect

urlpatterns = [
    path('', views.Home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('application_user/', views.application_user, name='application_user'),
    path('employees/', views.employee_list, name='employee_list'),
    path('update_emp/<int:id>/', views.update_emp, name='update_emp'),
    path('delete/<int:id>/', views.delete, name='delete'),
    path('add/', views.add_emp, name='add'),
    path('search_emp/', views.search_emp, name='search_emp'),
    path('export/csv/', views.export_to_csv, name='export_csv'),
    path('export/excel/',views.export_to_excel, name='export_excel'),
    path('register/', views.RegisterView, name='register'),
    path('login/', views.LoginView, name='login'),
    path('logout/', views.LogoutView, name='logout'),
    path('forgot-password/', views.ForgotPassword, name='forgot-password'),
    path('password-reset-sent/<str:reset_id>/', views.PasswordResetSent, name='password-reset-sent'),
    path('reset-password/<str:reset_id>/', views.ResetPassword, name='reset-password'),
    path('employee/<int:pk>/', views.employee_detail, name='employee_detail'),
    path('todos/', views.todo_list, name='todo_list'),
    path('todos/create/', views.create_task, name='create_task'),
    path('todos/edit/<int:task_id>/', views.edit_task, name='edit_task'),
    path('todos/delete/<int:task_id>/', views.delete_task, name='delete_task'),
    path('todos/complete/<int:task_id>/', views.mark_complete, name='mark_complete'),

   
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

