from django.urls import path
from .views import chat_view, send_message, mark_as_read, delete_message
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('<int:receiver_id>/', chat_view, name='chat_view'),
    path('send_message/', send_message, name='send_message'),
    path('message/read/<int:message_id>/', mark_as_read, name='mark_as_read'),
    path('chat/message/delete/<int:message_id>/', delete_message, name='delete_message'),  # Removed 'chat/' for consistency
]

# Static files (for development)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
