from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.models import User
from .models import Message  # Assuming Message is defined in your models
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required

@login_required
def chat_view(request, receiver_id):
    """Render the chat view between the current user and the receiver."""
    receiver = get_object_or_404(User, id=receiver_id)
    messages = Message.objects.filter(
        sender__in=[request.user, receiver],
        receiver__in=[request.user, receiver]
    ).order_by('timestamp')  # Adjust according to your model field

    context = {
        'receiver': receiver,
        'messages': messages,
    }
    return render(request, 'chat/chat.html', context)

@login_required
def mark_as_read(request, message_id):
    """Mark a message as read."""
    message = get_object_or_404(Message, id=message_id)
    if message.receiver == request.user:
        message.read = True  # Adjust according to your model field
        message.save()
        return JsonResponse({'success': True, 'message': 'Message marked as read.'})
    return JsonResponse({'success': False, 'error': 'Unauthorized'}, status=403)

@login_required
def delete_message(request, message_id):
    """Delete a message."""
    # Ensure that the request method is POST to prevent accidental deletions
    if request.method == 'POST':
        message = get_object_or_404(Message, id=message_id, sender=request.user)
        message.delete()
        return JsonResponse({'success': True, 'message': 'Message deleted.'})
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method.'}, status=400)

@login_required
def send_message(request):
    """Send a message."""
    if request.method == 'POST':
        content = request.POST.get('content')
        receiver_id = request.POST.get('receiver_id')

        # Create and save the message
        message = Message.objects.create(
            content=content,
            sender=request.user,
            receiver_id=receiver_id
        )

        # Return a response with the message details
        return JsonResponse({
            'success': True,
            'content': message.content,
            'timestamp': message.timestamp.strftime("%I:%M %p, %Y-%m-%d"),  # Format timestamp with date
            'sender_username': request.user.username  # Ensure the username is included
        })

    return JsonResponse({'success': False, 'error': 'Invalid request'})
